dir=/media/CD38-DA39/bin/qdjs/qdjs910/desktop-js
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$dir'/lib/lib'
export QT_PLUGIN_PATH=$dir'/lib/plugins'
#./qdjs
$dir/qdjs $1 $2 $3 $4

