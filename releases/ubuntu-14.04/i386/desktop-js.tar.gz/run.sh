dir=`pwd`
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$dir'/lib/lib'
export QT_PLUGIN_PATH=$dir'/lib/plugins'
./hw
