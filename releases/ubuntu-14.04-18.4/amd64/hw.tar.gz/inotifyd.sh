#!/bin/bash
/opt/qt-desktop-js/default/tools/inotifyd.run /home/x1404/tmp/Cvfjt ukfdyjt сказку не спугнут 2>&1
